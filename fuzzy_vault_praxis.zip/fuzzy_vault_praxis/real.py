# this file was used to generate the fuzzy vaults in vaults.py

# A person's biometric data should never be stored in the clear...this file
# should be destroyed...

people = {
        #"Jonas Winkler": [0.22, 1.23, 2.342, 0.33, 1.27,
        #                  0.34, 2.32, 3.98, 1.254, 0.03],
        #"Ravinder Sangar": [0.32, 1.32, 2.452, 0.49, 1.43,
        #                  0.34, 2.52, 3.55, 1.233, 0.001],
        "Felix Baumann": [0.45, 1.11, 2.321, 0.12, 1.11,
                          0.22, 2.91, 3.554, 1.33, 0.01]
}
