<?php

$degree = 4; #degree 4 polynomial
$t = 10; #number of features in each template
$r = 40; #number of chaff points

function getCoefficients($word){
  $word = strtoupper($word);
  $n = count($word) / $degree;
  if ($n < 1) {
    $substrings = str_split($word, 3);
    $coeff = [];
    foreach ($substrings as $substr) {
      $num = 0;
      $charArray = str_split($substr, 1);
      foreach ($charArray as $x => $char) {
        $num += ord($char) * pow(100, $x);
        #echo($num ."\n");
      }
      array_push($coeff, pow($num,1/3));
    }
  }
  return $coeff;
}

function pX($x, $coeffs) {
  $y = 0;
  $degree = count($coeffs) -1;

  foreach ($coeffs as $coeff) {
    $y += pow($x, $degree) *$coeff;
    $degree -= 1;
  }
  return $y;
}

function lock($secret, $template) {
  $vault = [];
  $coeffs = getCoefficients($secret);

  foreach ($template as $point) {
    array_push($vault, [$point, pX($point, $coeffs)]);
  }

  $maxX = max($template);

  foreach ($vault as $va) {
    $temp += [$va[1]];
  }
  $maxY = max($temp);

  foreach(range($t, $r) as $i) {
    $x = uniform(0, $maxX * 1.1);
    $y = uniform(0, $maxY * 1.1);
    array_push($vault, [$x, $y]);
  }
  shuffle($vault);
  return $vault;
}

function uniform($a, $b) {
  if($a < $b)
    return $a + ($b - $a) * (mt_rand() / mt_getrandmax());
  else
    return $b + ($a - $b) * (mt_rand() / mt_getrandmax());
}

function approxEqual($a, $b, epsilon) {
  return abs($a -$b) < $epsilon;
}

function unlock($template, $vault) {
  function project($x) {
    foreach ($vault as $point) {
      if(approxEqual($x, $point[0], 0.001))
        return [$x, $point[1]];
    }
    return null;
  }
  foreach ($template as $point) {
    if(project($point) != null)
      $pArray += project($point);
  }
  #Zip in Python
  #Q = tuple((alle x), (alle y))

}
#var_dump(getCoefficients("felix baumann"));
?>
